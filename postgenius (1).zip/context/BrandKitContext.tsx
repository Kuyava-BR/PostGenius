import React, { createContext, useState, useContext, ReactNode } from 'react';
import { BrandKit, PostGenerationJob, GeneratedPost } from '../types';

interface BrandKitContextType {
  step: number;
  setStep: (step: number) => void;
  brandKit: BrandKit;
  // FIX: Updated `setBrandKit` type to allow functional updates, resolving an error in `BrandKitStep.tsx` when setting state after an async operation.
  setBrandKit: React.Dispatch<React.SetStateAction<BrandKit>>;
  postJob: PostGenerationJob | null;
  setPostJob: (job: PostGenerationJob | null) => void;
  generatedPosts: GeneratedPost[];
  setGeneratedPosts: (posts: GeneratedPost[]) => void;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  error: string | null;
  setError: (error: string | null) => void;
}

const BrandKitContext = createContext<BrandKitContextType | undefined>(undefined);

export const BrandKitProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [step, setStep] = useState(1);
  const [brandKit, setBrandKit] = useState<BrandKit>({
    logo: null,
    logoUrl: '',
    brandColors: ['#6366F1', '#EC4899', '#F59E0B'],
    businessName: '',
    businessDescription: '',
    platforms: ['Instagram'],
  });
  const [postJob, setPostJob] = useState<PostGenerationJob | null>(null);
  const [generatedPosts, setGeneratedPosts] = useState<GeneratedPost[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  return (
    <BrandKitContext.Provider value={{
      step,
      setStep,
      brandKit,
      setBrandKit,
      postJob,
      setPostJob,
      generatedPosts,
      setGeneratedPosts,
      isLoading,
      setIsLoading,
      error,
      setError
    }}>
      {children}
    </BrandKitContext.Provider>
  );
};

export const useBrandKit = () => {
  const context = useContext(BrandKitContext);
  if (!context) {
    throw new Error('useBrandKit must be used within a BrandKitProvider');
  }
  return context;
};
