
import React from 'react';
import { useBrandKit } from '../context/BrandKitContext';
import { PostCard } from './PostCard';
import { Button } from './ui/Button';

const ResultsStep: React.FC = () => {
  const { generatedPosts, error, setStep, setGeneratedPosts } = useBrandKit();

  const handleStartOver = () => {
    setGeneratedPosts([]);
    setStep(2);
  };

  if (error) {
    return (
        <div className="text-center">
            <h3 className="text-xl font-semibold text-red-500">A Geração Falhou</h3>
            <p className="text-slate-600 dark:text-slate-400 mt-2 mb-4">{error}</p>
            <Button onClick={() => setStep(2)}>Tentar Novamente</Button>
        </div>
    );
  }

  if (generatedPosts.length === 0) {
    return (
        <div className="text-center">
            <h3 className="text-xl font-semibold">Nenhum Post Gerado</h3>
            <p className="text-slate-600 dark:text-slate-400 mt-2 mb-4">Algo deu errado. Por favor, tente novamente.</p>
            <Button onClick={handleStartOver}>Começar de Novo</Button>
        </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {generatedPosts.map((post, index) => (
          <PostCard key={index} post={post} />
        ))}
      </div>
      <div className="flex justify-center">
        <Button onClick={handleStartOver} variant="secondary">
          Gerar Novas Ideias
        </Button>
      </div>
    </div>
  );
};

export default ResultsStep;
