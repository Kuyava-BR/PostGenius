import React, { useState } from 'react';
import { GeneratedPost } from '../types';
import { Button } from './ui/Button';
import { ClipboardIcon } from './icons/ClipboardIcon';
import { DownloadIcon } from './icons/DownloadIcon';

interface PostCardProps {
  post: GeneratedPost;
}

export const PostCard: React.FC<PostCardProps> = ({ post }) => {
  const [copied, setCopied] = useState(false);

  const allHashtags = [...post.hashtags.business, ...post.hashtags.local, ...post.hashtags.niche];
  const formattedHashtags = allHashtags.map(h => `#${h}`).join(' ');

  const fullText = `${post.caption}\n\n${formattedHashtags}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = post.imageUrl;
    link.download = `postgenius-image-${Date.now()}.jpeg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-slate-50 dark:bg-slate-800/50 rounded-lg shadow-md overflow-hidden flex flex-col border border-slate-200 dark:border-slate-700">
      <div className="p-4 border-b border-slate-200 dark:border-slate-700">
        <h3 className="font-bold text-lg text-slate-800 dark:text-slate-100 truncate" title={post.title}>{post.title}</h3>
      </div>
      <div className="aspect-square w-full bg-slate-200 dark:bg-slate-700">
        <img src={post.imageUrl} alt="AI generated visual" className="w-full h-full object-cover" />
      </div>
      <div className="p-4 flex-grow flex flex-col">
        <div className="flex-grow mb-4 h-48 overflow-y-auto pr-2">
            <p className="text-sm text-slate-700 dark:text-slate-300 whitespace-pre-wrap">{post.caption}</p>
            <div className="mt-3">
                <p className="text-xs text-indigo-500 dark:text-indigo-400 break-words">
                  {formattedHashtags}
                </p>
            </div>
        </div>
        <div className="flex gap-2 mt-auto">
          <Button onClick={handleCopy} variant="secondary" className="w-full">
            <ClipboardIcon className="h-4 w-4 mr-2" />
            {copied ? 'Copiado!' : 'Copiar Texto'}
          </Button>
          <Button onClick={handleDownload} variant="secondary" className="w-full">
            <DownloadIcon className="h-4 w-4 mr-2" />
            Salvar Imagem
          </Button>
        </div>
      </div>
    </div>
  );
};