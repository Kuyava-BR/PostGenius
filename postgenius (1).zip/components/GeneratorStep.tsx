
import React, { useState } from 'react';
import { useBrandKit } from '../context/BrandKitContext';
import { Button } from './ui/Button';
import { Textarea } from './ui/Input';
import { Select } from './ui/Select';
import { POST_OBJECTIVES, TONES_OF_VOICE } from '../constants';
import { generatePosts } from '../services/geminiService';
import { Spinner } from './ui/Spinner';

const GeneratorStep: React.FC = () => {
  const { brandKit, setStep, setGeneratedPosts, setIsLoading, setError, isLoading } = useBrandKit();
  const [objective, setObjective] = useState(POST_OBJECTIVES[0].value);
  const [description, setDescription] = useState('');
  const [tone, setTone] = useState(TONES_OF_VOICE[0].value);
  
  const loadingMessages = [
    "Aquecendo os motores criativos da IA...",
    "Criando legendas cativantes...",
    "Desenhando visuais impressionantes...",
    "Encontrando as hashtags perfeitas...",
    "Quase pronto, juntando tudo!",
  ];
  const [loadingMessage, setLoadingMessage] = useState(loadingMessages[0]);

  React.useEffect(() => {
    let interval: number;
    if (isLoading) {
      interval = window.setInterval(() => {
        setLoadingMessage(prev => {
          const currentIndex = loadingMessages.indexOf(prev);
          return loadingMessages[(currentIndex + 1) % loadingMessages.length];
        });
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    try {
      const results = await generatePosts(brandKit, { objective, description, tone });
      setGeneratedPosts(results);
      setStep(3);
    } catch (err: any) {
      setError(err.message || 'Ocorreu um erro inesperado.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center text-center p-8 min-h-[300px]">
        <Spinner className="h-12 w-12 text-indigo-500 mb-4" />
        <p className="text-lg font-semibold text-slate-700 dark:text-slate-300">{loadingMessage}</p>
        <p className="text-sm text-slate-500 dark:text-slate-400">Isso pode levar até um minuto.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Select label="Objetivo do Post" id="objective" options={POST_OBJECTIVES} value={objective} onChange={(e) => setObjective(e.target.value)} required />
      
      <Textarea label="Descrição Simples" id="description" value={description} onChange={(e) => setDescription(e.target.value)} rows={4} placeholder="Ex: Promoção de 20% OFF na limpeza de sofás neste fim de semana." required />
      
      <Select label="Tom de Voz" id="tone" options={TONES_OF_VOICE} value={tone} onChange={(e) => setTone(e.target.value)} required />
      
      <div className="flex justify-between items-center">
        <Button type="button" variant="secondary" onClick={() => setStep(1)}>Voltar</Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? <Spinner className="mr-2"/> : null}
          Gerar Ideias
        </Button>
      </div>
    </form>
  );
};

export default GeneratorStep;
