
import React, { useState, useRef, useCallback } from 'react';
import { useBrandKit } from '../context/BrandKitContext';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { CheckboxGroup } from './ui/Checkbox';
import { PLATFORMS } from '../constants';
import { extractColors } from '../utils/colorExtractor';

const BrandKitStep: React.FC = () => {
  const { brandKit, setBrandKit, setStep } = useBrandKit();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isExtracting, setIsExtracting] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setBrandKit({ ...brandKit, [e.target.name]: e.target.value });
  };

  const handlePlatformChange = (selected: string[]) => {
    setBrandKit({ ...brandKit, platforms: selected });
  };

  const handleColorChange = (index: number, color: string) => {
    const newColors = [...brandKit.brandColors];
    newColors[index] = color;
    setBrandKit({ ...brandKit, brandColors: newColors });
  };

  const handleLogoUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setIsExtracting(true);
      extractColors(url, 3)
        .then(colors => {
          setBrandKit(prev => ({ ...prev, logo: file, logoUrl: url, brandColors: colors }));
        })
        .catch(console.error)
        .finally(() => setIsExtracting(false));
    }
  }, [setBrandKit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div>
            <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                Upload do Logo
            </label>
            <div className="mt-1 flex items-center gap-4">
                {brandKit.logoUrl && <img src={brandKit.logoUrl} alt="Logo preview" className="h-16 w-16 rounded-full object-cover" />}
                <Button type="button" variant="secondary" onClick={() => fileInputRef.current?.click()}>
                {brandKit.logo ? 'Alterar Logo' : 'Enviar Logo'}
                </Button>
                <input type="file" accept="image/*" ref={fileInputRef} onChange={handleLogoUpload} className="hidden" />
            </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
            Cores da Marca {isExtracting && "(Extraindo...)"}
          </label>
          <div className="flex gap-2">
            {brandKit.brandColors.map((color, index) => (
              <div key={index} className="relative w-10 h-10 rounded-full border-2 border-slate-300 dark:border-slate-600" style={{ backgroundColor: color }}>
                <input type="color" value={color} onChange={(e) => handleColorChange(index, e.target.value)} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"/>
              </div>
            ))}
          </div>
        </div>
      </div>

      <Input label="Nome do Negócio" id="businessName" name="businessName" value={brandKit.businessName} onChange={handleInputChange} placeholder="Ex: LimpaPro Higienização" required />
      
      <div>
        <label htmlFor="businessDescription" className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
          Breve Descrição do Negócio
        </label>
        <textarea id="businessDescription" name="businessDescription" value={brandKit.businessDescription} onChange={handleInputChange} rows={3} className="block w-full px-3 py-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 rounded-md text-sm shadow-sm placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" placeholder="Ex: Somos uma empresa de higienização de estofados que atende a domicílio na cidade X." required />
      </div>

      <CheckboxGroup label="Plataformas Principais" options={PLATFORMS} selectedOptions={brandKit.platforms} onChange={handlePlatformChange} />
      
      <div className="flex justify-end">
        <Button type="submit">Salvar e Continuar</Button>
      </div>
    </form>
  );
};

export default BrandKitStep;
