
import React from 'react';

export const LogoIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M12 3a9 9 0 0 1 9 9h-2a7 7 0 0 0-7-7V3Z" fill="currentColor" />
    <path d="M12 21a9 9 0 0 1-9-9h2a7 7 0 0 0 7 7v2Z" fill="currentColor" />
    <path d="M3 12a9 9 0 0 1 9-9v2a7 7 0 0 0-7 7H3Z" fill="currentColor" />
    <path d="M21 12a9 9 0 0 1-9 9v-2a7 7 0 0 0 7-7h2Z" fill="currentColor" />
    <circle cx="12" cy="12" r="3" fill="currentColor" />
  </svg>
);
