import { GoogleGenAI, Type } from "@google/genai";
import { BrandKit, GeneratedPost, PostGenerationJob } from "../types";

const textModel = "gemini-2.5-flash";
const imageModel = "imagen-4.0-generate-001";

// Helper function to initialize the AI client on demand
const getAiInstance = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error("A variável de ambiente API_KEY não está definida.");
    }
    return new GoogleGenAI({ apiKey });
};

const overlayLogo = (baseImageUrl: string, logoUrl: string): Promise<string> => {
    return new Promise((resolve, reject) => {
        const baseImage = new Image();
        baseImage.crossOrigin = 'Anonymous';
        baseImage.onload = () => {
            const logoImage = new Image();
            logoImage.crossOrigin = 'Anonymous';
            logoImage.onload = () => {
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                if (!ctx) {
                    return reject('Não foi possível obter o contexto do canvas');
                }

                canvas.width = baseImage.width;
                canvas.height = baseImage.height;
                ctx.drawImage(baseImage, 0, 0);

                const logoAspectRatio = logoImage.width / logoImage.height;
                const logoMaxSize = canvas.width * 0.20; // Max size is 20% of image width

                let logoWidth, logoHeight;
                if (logoAspectRatio >= 1) { // Landscape or square logo
                    logoWidth = logoMaxSize;
                    logoHeight = logoMaxSize / logoAspectRatio;
                } else { // Portrait logo
                    logoHeight = logoMaxSize;
                    logoWidth = logoMaxSize * logoAspectRatio;
                }
                
                const margin = canvas.width * 0.04; // 4% margin
                const logoX = canvas.width - logoWidth - margin;
                const logoY = margin;

                ctx.drawImage(logoImage, logoX, logoY, logoWidth, logoHeight);

                resolve(canvas.toDataURL('image/jpeg', 0.9));
            };
            logoImage.onerror = (err) => reject(`Falha ao carregar a imagem do logo: ${err}`);
            logoImage.src = logoUrl;
        };
        baseImage.onerror = (err) => reject(`Falha ao carregar a imagem base: ${err}`);
        baseImage.src = baseImageUrl;
    });
};


const generateTextContent = async (brandKit: BrandKit, postJob: PostGenerationJob): Promise<any> => {
    const ai = getAiInstance();
    const prompt = `
    Você é um especialista em marketing de mídias sociais chamado PostGenius. Sua tarefa é gerar 3 opções de posts completos e distintos para uma pequena empresa.

    **Informações da Empresa (Kit de Marca):**
    - **Nome do Negócio:** ${brandKit.businessName}
    - **Descrição do Negócio:** ${brandKit.businessDescription}
    - **Plataformas Alvo:** ${brandKit.platforms.join(', ')}

    **Requisitos do Post:**
    - **Objetivo:** ${postJob.objective}
    - **Detalhes:** ${postJob.description}
    - **Tom de Voz:** ${postJob.tone}

    **Instruções:**
    Para cada uma das 3 opções, você deve fornecer:
    1.  **title:** Um título curto e criativo para o post (máximo 5 palavras).
    2.  **visualPrompt:** Um prompt de imagem detalhado para um modelo de IA de texto para imagem. O objetivo é gerar uma imagem que combine **fotografia extremamente fotorrealista com um design gráfico moderno sobreposto**.
        - **BASE DA IMAGEM (FOTOGRAFIA):**
            - **REGRA MAIS IMPORTANTE: SEM TEXTO!** A imagem gerada NÃO PODE conter, sob nenhuma circunstância, qualquer tipo de texto, letras, números, palavras, logotipos ou marcas d'água. A imagem deve ser 100% visual.
            - **Estilo:** A fotografia base deve ser profissional e cinematográfica. Use termos como 'fotografia de produto', 'fotografia de estilo de vida', 'iluminação dramática', 'alta profundidade de campo', 'bokeh suave', 'textura realista', 'captura de filme 35mm', 'cores ricas e naturais', 'hiperdetalhado', 'qualidade 8k'.
            - **Qualidade:** A fotografia DEVE parecer real. **NÃO PODE TER aspecto de 3D, render, CGI, ou ilustração.** Foco total em realismo. Evite feições exageradas, pele com aspecto de plástico ou iluminação artificial de estúdio genérico.
            - **Conteúdo:** A cena deve ser autêntica e contar uma história visual relacionada ao objetivo do post.
            - **Composição para Gráfico:** A composição da fotografia deve criar um 'espaço negativo' (como um céu, parede ou fundo desfocado) no canto superior direito. Esta área deve ser visualmente limpa e livre de elementos importantes.

        - **DESIGN GRÁFICO SOBREPOSTO:**
            - **Descrição:** Sobre a fotografia, adicione um design gráfico minimalista e elegante.
            - **Elementos:** O design deve usar apenas formas geométricas abstratas (linhas finas, arcos, círculos parciais) e efeitos de luz sutis (brilhos suaves, gradientes delicados).
            - **CORES DO DESIGN:** Utilize **EXCLUSIVAMENTE** as cores azul ciano (#38b6ff) e branco (#ffffff) para TODOS os elementos do design gráfico. Nenhuma outra cor é permitida para esta camada de design.
            - **Integração:** O design deve se integrar harmoniosamente, complementando a foto sem cobrir os elementos principais. Posicione os gráficos de forma elegante, talvez nas bordas ou no 'espaço negativo'. O resultado final deve ser uma peça de marketing coesa e profissional.

        - **Instruções Específicas:**
            - Para "Antes e Depois": Descreva uma imagem fotorrealista de tela dividida, com iluminação e composição dramáticas. O design gráfico pode ser uma linha divisória estilizada ou elementos que emanam do lado do 'depois'.
            - Para "Promoção": Descreva uma cena que evoque o benefício da promoção. O design gráfico pode ser usado para enquadrar sutilmente o produto ou criar um ponto de foco.
            - Para "Prova Social": Descreva um retrato autêntico de uma pessoa. O design pode adicionar um toque de elegância, como arcos sutis ao redor do sujeito.
    3.  **caption:** Uma legenda atraente, adaptada para as plataformas e o tom de voz especificados. DEVE terminar com uma Chamada para Ação (CTA) forte e clara, relevante para o objetivo. Use emojis que se encaixem no tom.
    4.  **hashtags:** Um bloco estruturado de hashtags relevantes (sem o símbolo '#'), categorizadas em três tipos com base na descrição do negócio: 'business' (relacionadas ao setor), 'local' (relacionadas à cidade/região mencionada) e 'niche' (muito específicas do serviço/produto).

    Gere exatamente 3 opções únicas.
    `;

    const response = await ai.models.generateContent({
        model: textModel,
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.ARRAY,
                items: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        visualPrompt: { type: Type.STRING },
                        caption: { type: Type.STRING },
                        hashtags: {
                            type: Type.OBJECT,
                            properties: {
                                business: { type: Type.ARRAY, items: { type: Type.STRING } },
                                local: { type: Type.ARRAY, items: { type: Type.STRING } },
                                niche: { type: Type.ARRAY, items: { type: Type.STRING } },
                            },
                        },
                    },
                },
            },
        }
    });

    try {
        const jsonText = response.text.trim();
        return JSON.parse(jsonText);
    } catch (e) {
        console.error("Falha ao analisar a resposta JSON do Gemini:", response.text);
        throw new Error("Recebido um formato inválido da IA de geração de texto.");
    }
};

const generateImage = async (prompt: string): Promise<string> => {
    const ai = getAiInstance();
    const response = await ai.models.generateImages({
        model: imageModel,
        prompt: prompt,
        config: {
            numberOfImages: 1,
            outputMimeType: 'image/jpeg',
            aspectRatio: '1:1',
        },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
        return response.generatedImages[0].image.imageBytes;
    }
    throw new Error("A geração de imagem não conseguiu produzir uma imagem.");
};

export const generatePosts = async (brandKit: BrandKit, postJob: PostGenerationJob): Promise<GeneratedPost[]> => {
    const textResults = await generateTextContent(brandKit, postJob);

    if (!Array.isArray(textResults) || textResults.length === 0) {
        throw new Error("A IA não gerou nenhuma ideia de post.");
    }

    const imageGenerationPromises = textResults.map(result => generateImage(result.visualPrompt));
    const base64ImageResults = await Promise.all(imageGenerationPromises);

    const rawImageUrls = base64ImageResults.map(base64 => `data:image/jpeg;base64,${base64}`);

    let finalImageUrls = rawImageUrls;
    if (brandKit.logoUrl) {
        try {
            const overlayPromises = rawImageUrls.map(imageUrl => overlayLogo(imageUrl, brandKit.logoUrl));
            finalImageUrls = await Promise.all(overlayPromises);
        } catch (overlayError) {
            console.error("Erro ao sobrepor o logo:", overlayError);
            // Fallback para imagens brutas se a sobreposição falhar
        }
    }

    return textResults.map((result, index) => ({
        ...result,
        imageUrl: finalImageUrls[index],
    }));
};