
// A simple color quantization to find the most common colors
const quantize = (rgbValues: number[][], maxColors: number) => {
    if (rgbValues.length === 0) {
        return [];
    }
  
    const colorMap: { [key: string]: number } = {};
    rgbValues.forEach(rgb => {
      const key = rgb.join(',');
      if (!colorMap[key]) {
        colorMap[key] = 0;
      }
      colorMap[key]++;
    });
  
    const sortedColors = Object.keys(colorMap)
      .sort((a, b) => colorMap[b] - colorMap[a])
      .map(key => key.split(',').map(Number));
  
    return sortedColors.slice(0, maxColors);
  };
  
  export const extractColors = (imageUrl: string, count: number = 3): Promise<string[]> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'Anonymous';
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          return reject('Could not get canvas context');
        }
  
        const width = img.width;
        const height = img.height;
        canvas.width = width;
        canvas.height = height;
  
        ctx.drawImage(img, 0, 0, width, height);
  
        const imageData = ctx.getImageData(0, 0, width, height).data;
        const pixels: number[][] = [];
  
        // Sample pixels to improve performance
        const sampleRate = Math.max(1, Math.floor(imageData.length / 4 / 1000)); 
  
        for (let i = 0; i < imageData.length; i += 4 * sampleRate) {
          const r = imageData[i];
          const g = imageData[i + 1];
          const b = imageData[i + 2];
          pixels.push([r, g, b]);
        }
  
        const colorPalette = quantize(pixels, count);
  
        const hexPalette = colorPalette.map(([r, g, b]) => {
          return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase()}`;
        });
  
        resolve(hexPalette);
      };
      img.onerror = (err) => {
        reject(`Failed to load image: ${err}`);
      };
      img.src = imageUrl;
    });
  };
